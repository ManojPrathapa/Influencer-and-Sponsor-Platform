first cd into code folder 
then create virtual env using python -m venv venv
then activate the Script using .\venv\Scripts\activate
and then do pip install flask flask_sqlalchemy flask_login flask_wtf
and pip install flask-bcrypt
then type flask run
incase erorrs pop up about flask inports it is because the interpreter hasnt been changed to the venv 